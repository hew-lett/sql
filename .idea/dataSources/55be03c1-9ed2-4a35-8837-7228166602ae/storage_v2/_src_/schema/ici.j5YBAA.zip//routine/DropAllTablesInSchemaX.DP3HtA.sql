create
    definer = root@localhost procedure DropAllTablesInSchemaX()
BEGIN
    DECLARE done INT DEFAULT 0;
    DECLARE tableName VARCHAR(255);

    -- Declare cursor
    DECLARE cur CURSOR FOR
        SELECT table_name
        FROM information_schema.tables
        WHERE table_schema = 'ICI';

    -- Declare handlers
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;

    OPEN cur;

    DROP_TABLES: LOOP
        FETCH cur INTO tableName;
        IF done THEN
            LEAVE DROP_TABLES;
        END IF;
        SET @sqlStatement = CONCAT('DROP TABLE ICI.`', tableName, '`');
        PREPARE stmt FROM @sqlStatement;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END LOOP DROP_TABLES;
    CLOSE cur;
END;

